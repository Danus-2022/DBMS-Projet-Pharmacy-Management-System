-- phpMyAdmin SQL Dump
-- version 5.0.3
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jan 22, 2021 at 10:04 AM
-- Server version: 10.4.14-MariaDB
-- PHP Version: 7.2.34

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `pharmacy`
--

DELIMITER $$
--
-- Procedures
--
CREATE DEFINER=`root`@`localhost` PROCEDURE `getfeedback` ()  select id, product,cname ,feedback from feedback$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `get_stock` ()  NO SQL
select company,sell_type,actual_price,(actual_price+actual_price/2) as sell_price ,(actual_price*0.5) as fifty_percent_hike_selll_profit_on_actual_price from stock$$

DELIMITER ;

-- --------------------------------------------------------

--
-- Table structure for table `feedback`
--

CREATE TABLE `feedback` (
  `id` int(11) NOT NULL,
  `cname` varchar(100) NOT NULL,
  `product` varchar(100) NOT NULL,
  `feedback` varchar(100) NOT NULL,
  `sid` int(100) DEFAULT NULL,
  `ssid` int(100) DEFAULT NULL,
  `uid` int(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `feedback`
--

INSERT INTO `feedback` (`id`, `cname`, `product`, `feedback`, `sid`, `ssid`, `uid`) VALUES
(34, 'danu', 'apachin', 'good	', 41, 57, 1),
(35, 'anush', 'apachin', 'good	', 42, 57, 1),
(36, 'aniketh', 'paracetamol', 'good	', 43, 58, 1),
(37, 'diraj', 'ginger', 'good	', 44, 59, 1),
(38, 'danu', 'z', 'good	', 45, 60, 1),
(39, 'deepti', 'atin', 'good	', 46, 61, 1),
(40, 'ramu', 'acrogin', 'good	', 47, 62, 1),
(41, 'anush', 'paracetomol', 'good	', 46, 61, 1),
(42, 'gayatri', 'paracetamol', 'good	', 45, 62, 1),
(43, 'benjamin', 'vitin', 'good	', 46, 63, 1);

--
-- Triggers `feedback`
--
DELIMITER $$
CREATE TRIGGER `insert_triiger` AFTER INSERT ON `feedback` FOR EACH ROW insert into log values (null,new.id,new.cname,new.product,new.feedback,"inserted",now())
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Table structure for table `log`
--

CREATE TABLE `log` (
  `fid` int(11) NOT NULL,
  `id` int(100) NOT NULL,
  `cname` varchar(100) NOT NULL,
  `product` varchar(100) NOT NULL,
  `feedback` varchar(100) NOT NULL,
  `action` varchar(100) NOT NULL,
  `cdate` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `log`
--

INSERT INTO `log` (`fid`, `id`, `cname`, `product`, `feedback`, `action`, `cdate`) VALUES
(1, 13, 'sukku', 'crocin', 'good	', 'inserted', '2021-01-04 19:54:33'),
(2, 14, 'benjamin', 'dolo', '	good', 'inserted', '2021-01-04 20:21:50'),
(3, 15, 'indra', 'meftal', 'good	', 'inserted', '2021-01-04 20:24:38'),
(5, 17, 'anush', 'omez', '	good', 'inserted', '2021-01-04 21:16:33'),
(36, 24, 'anu', 'olov', 'good	', 'inserted', '2021-01-20 15:40:43'),
(37, 25, 'danu', 'olov', 'good	', 'inserted', '2021-01-20 15:42:24'),
(38, 26, 'danu', 'olov', 'good	', 'inserted', '2021-01-20 15:48:29'),
(39, 27, 'suraj', 'paracetomol', 'good	', 'inserted', '2021-01-20 16:00:15'),
(40, 28, 'danush', 'olov', 'good	', 'inserted', '2021-01-20 16:04:06'),
(41, 29, 'danu', 'olov', 'good	', 'inserted', '2021-01-20 16:05:16'),
(42, 30, 'danu', 'olov', 'good	', 'inserted', '2021-01-20 16:26:48'),
(43, 31, 'ankith', 'olov', 'ok good', 'inserted', '2021-01-20 16:34:47'),
(44, 32, 'danu', 'olov', 'good	', 'inserted', '2021-01-20 16:35:40'),
(45, 33, 'suraj', 'olov', 'good', 'inserted', '2021-01-20 16:39:28'),
(46, 34, 'danu', 'apachin', 'good	', 'inserted', '2021-01-20 17:27:25'),
(47, 35, 'anush', 'anacin', 'good	', 'inserted', '2021-01-20 17:29:01'),
(48, 36, 'aniketh', 'paracetamol', 'good	', 'inserted', '2021-01-20 17:47:11'),
(49, 37, 'diraj', 'ginger', 'good	', 'inserted', '2021-01-20 18:24:45'),
(50, 38, 'danu', 'z', 'good	', 'inserted', '2021-01-20 19:42:56'),
(51, 39, 'deepti', 'atin', 'good	', 'inserted', '2021-01-20 19:48:43'),
(52, 40, 'ramu', 'acrogin', 'good	', 'inserted', '2021-01-21 08:53:04'),
(53, 41, 'anush', 'paracetomol', 'good	', 'inserted', '2021-01-21 09:33:43'),
(54, 42, 'gayatri', 'paracetamol', 'good	', 'inserted', '2021-01-21 09:41:29'),
(55, 43, 'benjamin', 'vitin', 'good	', 'inserted', '2021-01-21 09:50:55');

-- --------------------------------------------------------

--
-- Table structure for table `on_hold`
--

CREATE TABLE `on_hold` (
  `id` int(100) NOT NULL,
  `invoice_number` varchar(13) NOT NULL,
  `medicine_name` varchar(255) NOT NULL,
  `category` varchar(255) NOT NULL,
  `expire_date` date NOT NULL,
  `qty` bigint(11) NOT NULL,
  `type` varchar(10) NOT NULL,
  `cost` bigint(11) NOT NULL,
  `amount` bigint(11) NOT NULL,
  `profit_amount` bigint(11) NOT NULL,
  `date` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `on_hold`
--

INSERT INTO `on_hold` (`id`, `invoice_number`, `medicine_name`, `category`, `expire_date`, `qty`, `type`, `cost`, `amount`, `profit_amount`, `date`) VALUES
(97, 'RS-9209000', 'Apachin', 'Painkiller', '2024-05-20', 1, 'Bot', 10, 10, 2, '01/20/2021'),
(98, 'RS-9303009', 'Apachin', 'Painkiller', '2024-05-20', 1, 'Bot', 10, 10, 2, '01/20/2021'),
(99, 'RS-9000202', 'Paracetomol', 'Painkiller', '2022-01-20', 1, 'Tab', 7, 7, 2, '01/20/2021'),
(100, 'RS-0029992', 'Ginger', 'Painkiller', '2022-05-20', 1, 'Stp', 7, 7, 2, '01/20/2021'),
(101, 'RS-0039002', 'Z', 'Painkiller', '2023-05-20', 1, 'Bot', 7, 7, 2, '01/20/2021'),
(102, 'RS-2999200', 'Atin', 'Painkiller', '2022-10-20', 1, 'Tab', 7, 7, 2, '01/20/2021'),
(103, 'RS-9022903', 'Acrogin', 'Painkiller', '2022-05-21', 1, 'Tab', 7, 7, 2, '01/21/2021'),
(104, 'RS-0090299', 'Vitin', 'Painkilller', '2022-05-21', 1, 'Tab', 7, 7, 2, '01/21/2021'),
(105, 'RS-0999090', 'Vitamin C', 'Energy booster', '2021-01-22', 1, 'Tab', 20, 20, 10, '01/21/2021'),
(106, 'RS-2900020', 'Vitamin C', 'Energy booster', '2021-01-22', 1, 'Tab', 20, 20, 10, '01/21/2021');

-- --------------------------------------------------------

--
-- Table structure for table `sales`
--

CREATE TABLE `sales` (
  `id` int(100) NOT NULL,
  `invoice_number` varchar(13) NOT NULL,
  `medicines` varchar(255) NOT NULL,
  `quantity` varchar(255) NOT NULL,
  `total_amount` bigint(11) NOT NULL,
  `total_profit` bigint(11) NOT NULL,
  `Date` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `sales`
--

INSERT INTO `sales` (`id`, `invoice_number`, `medicines`, `quantity`, `total_amount`, `total_profit`, `Date`) VALUES
(34, 'RS-3302329', 'Zyper', '1(Tab)', 15, 3, '2021-01-17'),
(40, 'RS-0932022', 'Oval', '1(Tab)', 7, 2, '2021-01-20'),
(41, 'RS-9209000', 'Apachin', '1(Bot)', 10, 2, '2021-01-20'),
(42, 'RS-9303009', 'Apachin', '1(Bot)', 10, 2, '2021-01-20'),
(43, 'RS-9000202', 'Paracetomol', '1(Tab)', 7, 2, '2021-01-20'),
(44, 'RS-0029992', 'Ginger', '1(Stp)', 7, 2, '2021-01-20'),
(45, 'RS-0039002', 'Z', '1(Bot)', 7, 2, '2021-01-20'),
(46, 'RS-2999200', 'Atin', '1(Tab)', 7, 2, '2021-01-20'),
(47, 'RS-9022903', 'Acrogin', '1(Tab)', 7, 2, '2021-01-21'),
(48, 'RS-0090299', 'Vitin', '1(Tab)', 7, 2, '2021-01-21'),
(49, 'RS-0999090', 'Vitamin C', '1(Tab)', 20, 10, '2021-01-21'),
(50, 'RS-2900020', 'Vitamin C', '1(Tab)', 20, 10, '2021-01-21');

-- --------------------------------------------------------

--
-- Table structure for table `stock`
--

CREATE TABLE `stock` (
  `id` int(100) NOT NULL,
  `bar_code` varchar(255) NOT NULL,
  `medicine_name` varchar(100) NOT NULL,
  `category` varchar(100) NOT NULL,
  `quantity` int(100) NOT NULL,
  `used_quantity` int(100) NOT NULL,
  `remain_quantity` int(100) NOT NULL,
  `act_remain_quantity` int(10) NOT NULL,
  `register_date` date NOT NULL,
  `expire_date` date NOT NULL,
  `company` varchar(100) DEFAULT NULL,
  `sell_type` varchar(100) NOT NULL,
  `actual_price` int(100) NOT NULL,
  `selling_price` int(100) NOT NULL,
  `profit_price` varchar(100) NOT NULL,
  `status` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `stock`
--

INSERT INTO `stock` (`id`, `bar_code`, `medicine_name`, `category`, `quantity`, `used_quantity`, `remain_quantity`, `act_remain_quantity`, `register_date`, `expire_date`, `company`, `sell_type`, `actual_price`, `selling_price`, `profit_price`, `status`) VALUES
(51, '7989', 'Zyper', 'Painkiller', 17, 3, 14, 14, '2021-01-15', '2022-03-17', 'sun company', 'Tab', 12, 15, '3(25%)', 'Available'),
(56, '7878', 'Oval', 'Painkiller', 10, 4, 6, 6, '2020-12-30', '2021-02-20', 'divis', 'Tab', 5, 7, '2(40%)', 'Available'),
(57, '7963', 'Apachin', 'Painkiller', 72, 4, 68, 68, '2021-01-21', '2024-05-20', 'lupin', 'Bot', 8, 10, '2(25%)', 'Available'),
(58, '7410', 'Paracetomol', 'Painkiller', 120, 5, 115, 115, '2021-01-26', '2022-01-20', 'lupin', 'Tab', 5, 7, '2(40%)', 'Available'),
(59, '3636', 'Ginger', 'Painkiller', 62, 1, 61, 61, '2021-01-06', '2022-05-20', 'sun', 'Stp', 5, 7, '2(40%)', 'Available'),
(60, '9898', 'Z', 'Painkiller', 69, 1, 68, 68, '2021-01-13', '2023-05-20', 'cipla', 'Bot', 5, 7, '2(40%)', 'Available'),
(61, '7474', 'Atin', 'Painkiller', 118, 1, 117, 117, '2021-01-20', '2022-10-20', 'cipla', 'Tab', 5, 7, '2(40%)', 'Available'),
(62, '8520', 'Acrogin', 'Painkiller', 100, 1, 99, 99, '2021-01-12', '2022-05-21', 'biocon', 'Tab', 5, 7, '2(40%)', 'Available'),
(63, '7373', 'Vitin', 'Painkilller', 100, 1, 99, 99, '2020-12-31', '2022-05-21', 'biocon', 'Tab', 5, 7, '2(40%)', 'Available'),
(64, '1234', 'Vitamin C', 'Energy booster', 100, 2, 98, 98, '2021-01-21', '2021-01-22', 'biocon', 'Tab', 10, 20, '10(100%)', 'Available'),
(65, '36363', 'Vitamin-c', 'Energy booster', 100, 0, 100, 100, '2021-01-06', '2021-01-07', 'cipla', 'Tab', 5, 7, '2(40%)', 'Available');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(100) NOT NULL,
  `user_name` varchar(10) NOT NULL,
  `password` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `user_name`, `password`) VALUES
(1, 'someone', '123');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `feedback`
--
ALTER TABLE `feedback`
  ADD PRIMARY KEY (`id`),
  ADD KEY `sid` (`sid`),
  ADD KEY `ssid` (`ssid`),
  ADD KEY `uid` (`uid`);

--
-- Indexes for table `log`
--
ALTER TABLE `log`
  ADD PRIMARY KEY (`fid`);

--
-- Indexes for table `on_hold`
--
ALTER TABLE `on_hold`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `sales`
--
ALTER TABLE `sales`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `stock`
--
ALTER TABLE `stock`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `feedback`
--
ALTER TABLE `feedback`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=44;

--
-- AUTO_INCREMENT for table `log`
--
ALTER TABLE `log`
  MODIFY `fid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=56;

--
-- AUTO_INCREMENT for table `on_hold`
--
ALTER TABLE `on_hold`
  MODIFY `id` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=107;

--
-- AUTO_INCREMENT for table `sales`
--
ALTER TABLE `sales`
  MODIFY `id` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=51;

--
-- AUTO_INCREMENT for table `stock`
--
ALTER TABLE `stock`
  MODIFY `id` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=66;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `feedback`
--
ALTER TABLE `feedback`
  ADD CONSTRAINT `feedback_ibfk_1` FOREIGN KEY (`sid`) REFERENCES `sales` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `feedback_ibfk_2` FOREIGN KEY (`ssid`) REFERENCES `stock` (`id`),
  ADD CONSTRAINT `feedback_ibfk_3` FOREIGN KEY (`uid`) REFERENCES `users` (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
