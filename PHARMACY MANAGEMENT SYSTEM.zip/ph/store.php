<?php


 $connect = mysqli_connect("localhost","root","","pharmacy");

    $query="CALL getfeedback();";

      if($result=mysqli_query($connect,$query)) {

         while($row =mysqli_fetch_row($result))
         {
         
         echo "<pre>";
         print_r($row);
         }
         }
?>

