<?php
include('dbcon.php');
$q1="SELECT * FROM feedback;";
$r1=mysqli_query($con,$q1);
$resultcheck1=mysqli_num_rows($r1);
$chairs=mysqli_fetch_all($r1,MYSQLI_ASSOC);



 ?>






  <!DOCTYPE html>
  <html lang="en">
  <head>
    <body style="background-image: url('images/');">
      <meta charset="UTF-8">
      <title>Show Feedback</title>

    <style media="screen">
    #first
    {
      background-color: black;
      color: white;
    }


    tr:nth-child(odd)
    {
      background-color: #f3f3f3;
    }


    tr
    {
      border: 2px solid black;
    }

    td
    {
      padding: 10%;
      padding-top: 1%;
      padding-bottom: 1%;
      width: 20vw;
      border: 0px;
      border-style: ridge;
      text-align: center;
      font-size: 1.2vw;

    }

    ::-webkit-scrollbar
    {
      width:10px;
    }

    ::-webkit-scrollbar-track
    {
      background: #f1f1f1;
    }
    ::-webkit-scrollbar-thumb
    {
      background: #888;
    }
    ::-webkit-scrollbar-thumb:hover{
      background: #556;
    }
    </style>
  </head>

  <body>
    <div class="header">
      <h1 >Feedback</h1>

    </div>

      <div style="overflow:auto;">
        <div class="menu">

            <a href="index.php" class="active">Home</a>



        </div>

      </div>


  <div class="main">
    <div class="forms" style="width:60vw;height:25vw;margin-top:5vw;border: none;;overflow-y:scroll;margin-left:20%;">
    <form >
      <table >
      <tr id="first">
        <td>Customer Name</td>
        <td>Product</td>
        <td>Feedback</td>
      </tr>

        <?php
      foreach ($chairs as $chair) { ?>

        <tr >
          <td><?php echo htmlspecialchars($chair['cname']);?></td>
          <td><?php echo htmlspecialchars($chair['product']);?></td>
          <td><?php echo htmlspecialchars($chair['feedback']);?></td>
        </tr>

      <?php } ?>


    </table>

    </form>
      </div>
  </div>







  </body>
  </html>
