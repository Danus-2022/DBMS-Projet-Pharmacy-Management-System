

<!DOCTYPE html>
<html>
<head>
	<body style="background-image: url('images/d2.jfif');">
	<title>Feedback</title>
	<style type="text/css">
		form
		{
			width:300px;
			margin-left:40%;
			margin-top:10%;

		}
		input[type=text] {
  width: 100%;
  padding: 12px 20px;
  margin: 8px 0;
  box-sizing: border-box;
}

textarea
{
input[type=text] {
  width: 100%;
  padding: 12px 20px;
  margin: 8px 0;
  box-sizing: border-box;

}

</style>
</head>
<body>
<form method="post">
<label>Name</label>
<input type="text" name="cname">
<br>
<label>Products</label>
<input type="text" name="pro">
<br>
<label>Feedback</label>
<textarea rows="8" cols="35" name="feed">	</textarea>
<br>
<input type="submit" name="submit" value="submit">
</form>
<h1 style="text-align:center;color:red;"><?php
if(isset($_POST["submit"]))
{
include('dbcon.php');
	$cname=$_POST["cname"];
	$pro=$_POST["pro"];
	$feed=$_POST["feed"];
	$query="INSERT into feedback(cname,product,feedback) values('$cname','$pro','$feed');";
	if(mysqli_query($con,$query))
	{
		echo "Feedback Sent Successfully";
    header("refresh:2;url=index.php");
	}
	else
	{
		echo "Failed";
	}
}



 ?></h1>
</body>
</html>
